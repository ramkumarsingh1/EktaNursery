export default function ProductTableRow({ product }) {
    return (
        <tr>
            <td>{product.name}</td>
        </tr>
    );
}