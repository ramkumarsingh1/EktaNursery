import products from "../../data/products";
import ProductTable from "../../components/admin/ProductTable";
import { Link } from "react-router-dom";

export default function Products() {
    return (
        <div>

            <div className="mb-8 flex items-center justify-between">

                <div>
                    <h1 className="text-3xl font-bold">
                        Products
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Manage all nursery products.
                    </p>
                </div>

                <Link
                    to="/admin/products/add"
                    className="rounded-xl bg-green-700 px-5 py-3 font-medium text-white hover:bg-green-800"
                >
                    + Add Product
                </Link>

            </div>

            <ProductTable products={products} />

        </div>
    );
}