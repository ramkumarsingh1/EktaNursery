import Categories from "../components/home/Categories";
import FeatureCard from "../components/home/FeatureCard";
import FeaturedProducts from "../components/home/FeaturedProducts";
import Features from "../components/home/Features";
import Hero from "../components/home/Hero";
import Container from "../components/layout/Container";
import ProductCard from "../components/product/ProductCard";
import products from "../data/products";

export default function Home() {
    return (
        <>
        <Hero/>
        <Categories/>
        <FeaturedProducts/>
            <Container>
                <section className="py-10">
                    <h1 className="text-4xl font-bold text-center mb-10">
                        Featured Plants
                    </h1>

                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                        {products.map((product) => (
                            <ProductCard
                                key={product.id}
                                image={product.image}
                                name={product.name}
                                category={product.category}
                                price={product.price}
                                rating={product.rating}
                            />
                        ))}
                    </div>
                </section>
            </Container>
        </>

    );
}